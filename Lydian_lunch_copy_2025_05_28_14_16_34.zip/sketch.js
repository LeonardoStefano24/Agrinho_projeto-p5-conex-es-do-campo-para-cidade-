function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
// Número de pontos de conexão em cada lado

const numPoints = 10;

let fieldPoints = [];

let cityPoints = [];

function setup() {

  createCanvas(800, 600);

  // Criar pontos aleatórios no lado esquerdo (campo)

  for (let i = 0; i < numPoints; i++) {

    let x = random(50, width / 2 - 50);

    let y = random(50, height - 50);

    fieldPoints.push({ x: x, y: y });

  }

  // Criar pontos aleatórios no lado direito (cidade)

  for (let i = 0; i < numPoints; i++) {

    let x = random(width / 2 + 50, width - 50);

    let y = random(50, height - 50);

    cityPoints.push({ x: x, y: y });

  }

}

function draw() {

  background(220);

  // Desenhar o lado esquerdo (campo)

  fill(34, 139, 34); // verde

  rect(0, 0, width / 2, height);

  fill(0);

  textSize(16);

  textAlign(CENTER, TOP);

  text("Campo", width / 4, 10);

  // Desenhar árvores simples no campo

  fill(0, 100, 0);

  for (let pt of fieldPoints) {

    ellipse(pt.x, pt.y, 10, 10);

    // Opcional: desenhar uma árvore simples

    fill(139, 69, 19);

    rect(pt.x - 2, pt.y, 4, 10);

    fill(0, 100, 0);

  }

  // Desenhar o lado direito (cidade)

  fill(169, 169, 169); // cinza

  rect(width / 2, 0, width / 2, height);

  fill(0);

  textSize(16);

  textAlign(CENTER, TOP);

  text("Cidade", (3 * width) / 4, 10);

  // Desenhar prédios simples na cidade

  fill(105, 105, 105);

  for (let i = 0; i < 5; i++) {

    let x = width / 2 + 20 + i * 40;

    let h = random(50, 150);

    rect(x, height - h - 20, 20, h);

  }

  // Desenhar pontos de conexão e linhas entre eles

  stroke(0, 0, 255, 150); // linhas azuis semi-transparent

  for (let i = 0; i < numPoints; i++) {

    let start = fieldPoints[i];

    let end = cityPoints[i];

    line(start.x, start.y, end.x, end.y);

  }

  // Opcional: mover os pontos do lado esquerdo para criar dinamismo

  for (let pt of fieldPoints) {

    pt.y += sin(frameCount * 0.02 + pt.x) * 0.5;

  }
  
}